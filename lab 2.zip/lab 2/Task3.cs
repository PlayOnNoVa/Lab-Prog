﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hello
{
    class Program
    {
        static void Randome(ref int[] matrix)

        {
            Random rnd = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)

            {
                matrix[i] = rnd.Next(-5, 10);
            }
        }
        static void Output(int[] matrix)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                Console.Write("{0} ", matrix[i]);
            }
            Console.WriteLine();
        }


        static void Resize(ref int[] matrix)
        {
            int count = 0;
            int evenCount = 0;

            for (int i = 0; i < matrix.Length; i++)
            {
                if (matrix[i] % 2 == 0)
                {
                    evenCount++;
                }
            }

            int[] matrixResized = new int[matrix.Length + evenCount];

            for (int i = 0; i < matrix.Length; i++)
            {
                if (matrix[i] % 2 != 0)
                {
                    matrixResized[count] = matrix[i];
                    count++;
                }
                else
                {
                    matrixResized[count] = matrix[i];
                    count++;
                    matrixResized[count] = 0;
                    count++;
                }
            }

            Output(matrixResized);
        }

        static void Main(string[] args)
        {
            int n = Convert.ToInt32(Console.ReadLine());
            int[] matrix = new int[n];
            Randome(ref matrix);
            Output(matrix);
            Console.WriteLine();
            Console.WriteLine();
            Resize(ref matrix);

            Console.ReadKey();
        }
    }
}
