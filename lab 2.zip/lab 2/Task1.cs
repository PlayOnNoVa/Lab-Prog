﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hello
{
    class Program
    {
        static void Randome(ref int[,] matrix)

        {
            Random rnd = new Random();
            for (int i = 0; i < matrix.GetLength(0); i++)

            {
                for (int j = 0; j < matrix.GetLength(1); j++)
                {
                    string space = " ";
                    matrix[i, j] = rnd.Next(-5, 5);
                    if (matrix[i, j] >= 0)
                    {
                        space = "  ";
                    }
                    Console.Write("{0}{1} ", space, matrix[i, j]);
                }
                Console.WriteLine();
            }
        }

        static void Value(string n_m, ref int n, ref int m)
        {
            int[] n_m_Box = n_m.Split(' ').Select(int.Parse).ToArray();
            n = n_m_Box[0];
            m = n_m_Box[1];
        }

        static void CountWithoutZero(int n, int m, int[,] matrix)
        {
            int count = 0;
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                bool boolean = true;
                for (int j = 0; j < matrix.GetLength(1) && boolean == true; j++)
                {
                    if (matrix[i, j] == 0)
                    {
                        boolean = false;
                    }
                }
                if (boolean)
                {
                    count++;
                }
            }
            if (count > 0)
                Console.WriteLine("Number of rows without zero is " + count);
            else Console.WriteLine("No rows that do not contain zero");
        }
        static void Main(string[] args)
        {
            int n = 0;
            int m = 0;
            string n_m = Console.ReadLine();
            Value(n_m, ref n, ref m);
            int[,] matrix = new int[n, m];
            Randome(ref matrix);
            CountWithoutZero(n, m, matrix);

            Console.ReadKey();
        }
    }
}
