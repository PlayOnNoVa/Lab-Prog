﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hello
{
    class Program
    {
        static void Randome(ref int[][] matrix, int m)

        {

            Random rnd = new Random();

            for (int i = 0; i < matrix.Length; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    matrix[i][j] = rnd.Next(-50, 50);
                }
            }
        }

        static void RandomeRow(ref int[][] matrix, int m, ref int index)
        {
            Random rnd = new Random();

            for (int j = 0; j < m; j++)
            {
                matrix[index][j] = rnd.Next(-40, 50) - rnd.Next(-10, 10);
            }

        }

        static void Output(int[][] matrix, int m)
        {
            for (int i = 0; i < matrix.GetLength(0); i++)
            {
                for (int j = 0; j < m; j++)
                {
                    string space = " ";

                    if (matrix[i][j] >= 0)
                    {
                        space = "  ";
                    }
                    Console.Write("{0}{1}", space, matrix[i][j]);
                }
                Console.WriteLine();
            }
        }


        static void Resize(ref int[][] matrix, ref int[][] matrixResized, int m, int index)
        {
            int count = 0;
            bool flag = true;

            for (int i = 0; i < matrix.Length; i++)
            {
                if (count == index)
                {
                    RandomeRow(ref matrixResized, m, ref index);
                    count++;
                    flag = false;
                }
                for (int j = 0; j < m; j++)
                {
                    matrixResized[count][j] = matrix[i][j];
                }
                count++;
            }
            if (count == index && flag)
            {
                RandomeRow(ref matrixResized, m, ref index);
                count++;
            }
        }
        static void Value(string n_m, ref int n, ref int m)
        {
            int[] n_m_Box = n_m.Split(' ').Select(int.Parse).ToArray();
            n = n_m_Box[0];
            m = n_m_Box[1];
        }
        static void ArrayInitialization(ref int[][] matrix, int m)
        {
            for (int i = 0; i < matrix.Length; i++)
            {
                matrix[i] = new int[m];
            }
        }
        static void Main(string[] args)
        {
            int n = 0;
            int m = 0;
            string n_m = Console.ReadLine();
            Value(n_m, ref n, ref m);
            int index = Convert.ToInt32(Console.ReadLine());
            int[][] matrix = new int[n][];
            ArrayInitialization(ref matrix, m);
            Randome(ref matrix, m);
            Output(matrix, m);
            Console.WriteLine();
            Console.WriteLine();
            int[][] matrixResized = new int[n + 1][];
            ArrayInitialization(ref matrixResized, m);
            Resize(ref matrix, ref matrixResized, m, index);
            Output(matrixResized, m);
            Console.ReadKey();
        }
    }
}
