﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        Bitmap bmp;
        Graphics graph;
        Pen pen;
        int y0;
        int speed;
        public Form1()
        {
            InitializeComponent();
            Draw();
        }

        private void Draw()
        {
            bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            graph = Graphics.FromImage(bmp);
            pen = new Pen(Color.Coral, 10);


            y0 = 200;
            speed = 10;
            timer1.Enabled = true;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            graph.Clear(Color.White);

            graph.FillRectangle(Brushes.DarkRed, 160, 215, 200, 100);
            graph.FillEllipse(Brushes.DarkGray, 160, 195, 200, 40);
            graph.FillEllipse(Brushes.DarkRed, 160, 290, 200, 40);

            Point p0 = new Point(250, y0);
            Point p1 = new Point(120, 160);
            Point p2 = new Point(280, y0);
            Point p3 = new Point(410, 160);

            graph.DrawLine(pen, p0, p1);
            graph.DrawLine(pen, p2, p3);

            pictureBox1.Image = bmp;

            y0 += speed;
            if (y0 < 180 || y0 > 200)
            {
                speed = -speed;
            }
        }
    }
}
