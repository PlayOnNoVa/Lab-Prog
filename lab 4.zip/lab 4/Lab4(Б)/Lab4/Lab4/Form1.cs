﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Draw();
        }

        private void Draw()
        {
            Bitmap bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            Graphics graph = Graphics.FromImage(bmp);


            graph.FillRectangle(Brushes.Black, 150, 12, 186, 83);
            graph.FillRectangle(Brushes.DarkBlue, 160, 20, 170, 65);
            graph.FillRectangle(Brushes.Black, 233, 95, 20, 20);
            graph.FillRectangle(Brushes.Gray, 160, 128, 170, 45);
            graph.FillRectangle(Brushes.White, 168, 136, 152, 30);
            graph.FillRectangle(Brushes.Black, 60, 33, 50, 110);
            graph.FillRectangle(Brushes.DarkRed, 80, 116, 15, 15);
            graph.FillEllipse(Brushes.Gray, 350, 130, 20, 40);

            pictureBox1.Image = bmp;
        }

    }
}
